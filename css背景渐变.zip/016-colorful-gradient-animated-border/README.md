# Colorful gradient animated border

See demo on Codepen: https://codepen.io/comehope/pen/odpRKX

Watch interactive screencast on Scrimba: https://scrimba.com/c/cmQV7Hd

Read annotated source on Segmentfault(zh-cn): https://segmentfault.com/a/1190000014785816
